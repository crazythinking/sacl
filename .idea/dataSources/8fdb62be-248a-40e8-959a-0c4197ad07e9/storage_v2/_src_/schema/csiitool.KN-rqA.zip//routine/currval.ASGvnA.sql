create
    definer = root@`%` function currval(seq_name varchar(50)) returns int
BEGIN
     DECLARE VALUE INTEGER;
     SET VALUE = 0;
     SELECT current_value INTO VALUE
          FROM sequence
          WHERE NAME = seq_name;
     RETURN VALUE;
END;

